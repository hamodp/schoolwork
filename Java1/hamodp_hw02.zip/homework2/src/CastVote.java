import java.util.ArrayList;
import java.util.Scanner;

/*********************************************************************
 * CastVote class.
 *
 * takes a cast vote and creates an array of the choices
 * all classes that were in last home work were taken from Buell's choice
 * class
 * 
 *
 * @author Patrick Hamod
 * @version 1.00 2013-02-04
**/
public class CastVote {

	static private int staticVoteNumber = 0;

	  private int localVoteNumber = 0;

	  boolean isNewVote;

	  private String ballotStyle;
	  private String candidateContest;
	  private String ivo;
	  private String pctName;
	  private String pctNumber;
	  private String sequenceCode;
	  private String output ="";
	  private ArrayList <Choice> choiceList;
	  private String candidate;
	  private  String contest;
	  
	  
	  /*******************************************************************
	   *  constructor
	   *  
	   * @param pctData
	   * @param inputLine
	   */
	  CastVote(String pctData, String inputLine)
	  {
		  choiceList = new ArrayList<Choice>();
		  this.ballotStyle = "style";
		    this.candidateContest = "cand contest";
		    this.isNewVote = false;
		    this.ivo = "ivo";
		    this.localVoteNumber = staticVoteNumber;
		    this.pctName = "pctname";
		    this.pctNumber = "pctnumber";
		    this.extractPctInfo(pctData);
		    this.parseNewVoteInput(pctData, inputLine);
	  }
	  
  /*******************************************************************
   * acessors 
   */
  /********************************************************************
   * returns what the candidates are running for
   * 
   * @return contest
   */
	  public String getContest()
	  {
		  return contest;
	  }
	  
  /******************************************************************
   * returns the candidate running in the contest
   * 
   * @return candidate
   */
	  public String getCandidate()
	  {
		  return candidate;
	  }
	  
	  
  /*********************************************************************
   * takes the inputLine and gets the candidate and contest if the 
   * candidate is running for president or congress
   * 
   * @param inputLine
   */
	  public void addToCVR(String inputLine)
	  {
		  int index;
		  Choice choice = null;

		    
		    
		    if(inputLine.indexOf("President") >= 0)
		    {
		    	index = inputLine.indexOf("President");
		    	candidate = inputLine.substring(0, index);
		    	contest = inputLine.substring(index);
		    	choice = new Choice(candidate, contest);
		    	choiceList.add(choice);
		    	this.getChoiceForContest(contest);
		    }
		    
		      else if(inputLine.indexOf("CONG00") >= 0)
		      {
		    	index = inputLine.indexOf("CONG00");
			    candidate = inputLine.substring(0, index);
			    contest = inputLine.substring(index);
			    choice = new Choice(candidate, contest);
			    choiceList.add(choice);
			    this.getChoiceForContest(contest);
		      }
		      else
		      {
		    	  candidate = null;
		    	  contest = null;
		      }
		    output += inputLine + "\n";
	  }

  /******************************************************
   * takes the pct info and gets the pct number and name
   * 
   * @param pctInfo
   */
	  public void extractPctInfo(String pctInfo)
	  {
		  String s = "";
		    Scanner scanLine = null;
		    pctInfo = pctInfo.trim();
		    scanLine = new Scanner(pctInfo);

		    s = scanLine.next(); // read and toss the "PRECINCT"

		    this.pctNumber = scanLine.next();

		    s = scanLine.next(); // read and toss the hyphen

		    this.pctName = scanLine.nextLine().trim(); // read the rest of the line
		    scanLine.close();
		    
	  }

	  /***********************************************************************
	   * determines what the candidates are running for
	   * 
	   * @param whichContest
	   * @return returnVal
	   */
	  public Choice getChoiceForContest(String whichContest)
	  {
		  Choice returnVal=null;
		  for(Choice c:choiceList)
		  {
			  if(c.getContest().indexOf(whichContest) >= 0)
			  {
				  returnVal = c;
				  break;
			  }
		  }
		  return returnVal;
	  }

	 /*****************************************************************
	  * takes in the pct info and the line with the choices
	  * parses data this also formats the output to look nice and then 
	  * adds the votes to the arraylist containing the cast vote
	  * record
	  * 
	  * @param pctInfo
	  * @param inputLine
	  */
	  public void parseNewVoteInput(String pctInfo, String inputLine)
	  {
		  String s;
		    Scanner scanLine = null;

		    scanLine = new Scanner(inputLine);
		    this.ivo = scanLine.next().trim();
		    this.ballotStyle = scanLine.next().trim();

		    s = scanLine.next().trim();
		    if( s.equals("*") )
		    {
		      this.isNewVote = true;
		      ++staticVoteNumber;
		      this.localVoteNumber = staticVoteNumber;
		      s = scanLine.next().trim();
		    }
		    this.sequenceCode = s;
		    this.candidateContest = scanLine.nextLine();
		    
		    //creates the beginning header for each cast vote
		    if(inputLine.indexOf("*")>0)
		    {
		    	   output += String.format("%5d ", this.localVoteNumber);
				    output += String.format("%5s ", this.pctNumber);
				    output += String.format("%-20s ", this.pctName);
				    output += String.format("%6s ", this.ivo);
				    
				    output += "N ";
				  
				    output += String.format("%3s ", this.ballotStyle);
				    output += String.format("%4s ", this.sequenceCode);
		    }
		    
		    //lines up rest of vote
		    else
		    {
		    	output += String.format("%52s", ""); 
		    }
		    this.addToCVR(candidateContest);
		   
		    scanLine.close();
	  }
	  
/************************************************
 * to String method
 * 
 * @return vote records and the choice associated
 * with vote
 */
	  public String toString()
	  {

		    return output;

	  }
}
