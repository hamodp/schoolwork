import java.util.Scanner;
public interface IDTD
{
//  static public boolean isLegalTag(String tag);

  public void readFile(Scanner inFile);

  public String toString();

} // public interface IDTD
