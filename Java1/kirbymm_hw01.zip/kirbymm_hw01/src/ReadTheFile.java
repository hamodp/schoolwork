import java.util.ArrayList;
import java.util.Scanner;
/*******************************************************************
 * Copyright (C) 2013 by Michal M. Kirby.  All rights reserved.
 * 
 * @author Michal M. Kirby
 * @version 2013-01-23
 */

public class ReadTheFile implements IReadTheFile {
	/*********************************************************************
	 * Instance variables for the class.
	**/
	
	private ArrayList<Choice> theList;
	private static String pctData; 
	/*********************************************************************
	 * Constructor.
	 *
	 * @param inFile the 'Scanner' from which to create the list
	 ******************************************************************/
	
	public ReadTheFile(Scanner inFile)
	  {
	    this.theList = new ArrayList<Choice>();
	    this.readFile(inFile);
	  }
	// public ReadTheFile(Scanner inFile)
	/*********************************************************************
	 * Method to get the precinct from the input header line.
	 * This method knows that precinct info starts with the 'String'
	 * "PRECINCT" and ends before the 'String' "ELECTION".
	 *
	 * @param inputLine the line to parse
	 * @return the precinct
	**/
	@Override
	public String getPctData(String inputLine) {
		// TODO Auto-generated method stub
		String output;
		output = inputLine.substring(inputLine.indexOf("PRECINCT"), inputLine.indexOf("ELECTION"));
		
		return output;
		
	}
	/*********************************************************************
	 * Method to determine if the line is a cast vote choice.
	 *
	 * The definition of being a cast vote choice is that the zeroth char 
	 * is a leading '5' in an iVotronic serial number.
	 *
	 * @param inputLine the line to parse
	 * @return the answer to the question
	**/
	@Override
	public boolean isChoice(String inputLine) {
		// TODO Auto-generated method stub
		return inputLine.startsWith("5");
	}
	/*********************************************************************
	 * Method to determine if the line is a header line.
	 *
	 * The definition of being a header line is that the line begins
	 * with the 'String' "RUN DATE".
	 *
	 * @param inputLine the line to parse
	 * @return the answer to the question
	**/
	@Override
	public boolean isHeader(String inputLine) {
		// TODO Auto-generated method stub
		return inputLine.startsWith("RUN DATE");
	}
	/*********************************************************************
	 * Method to read the cast vote records into the 'ArrayList'.
	 *
	 * We read line by line. If it's a header, we pull off the pct info.
	 * If not a header but is a cast vote line, we create a new 'Choice'
	 * with the pct data and the line and add the 'Choice' to the
	 * 'ArrayList'. 
	 *
	 * @param inFile the Scanner from which to read.
	**/
	@Override
	public void readFile(Scanner inFile) {
		// TODO Auto-generated method stub
		String pctData = "" ;
		while(inFile.hasNext()){
			String input = inFile.nextLine();
			if(isHeader(input)){
				pctData = getPctData(input);
			} else if (isChoice(input)){
				Choice c = new Choice();
				c.parseInput(pctData, input);
				theList.add(c);
			}
		}
	}
	/*********************************************************************
	 * Method to <code>toString</code> the class.
	 *
	 * @return the <code>toString<c/ode> of the list.
	**/
	public String toString () {
		String printout = ""; 
		
		for(Choice c: theList){
			printout += (c + "\n");
		}
		
		return printout;
	}

}
