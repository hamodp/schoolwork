import java.util.Scanner;
/***************************************************
 * Copyright (C) 2013 by Michal M. Kirby.  All rights reserved.
 * 
 * @author Michal M. Kirby
 * @version 1.0 2013-01-23
 */

public class Choice implements IChoice {

	static private int staticVoteNumber = 0;
	private int localVoteNumber = 0;
	boolean isNewVote;
	private String ballotStyle;
	private String candidateContest;
	private String ivo;
	private String pctName;
	private String pctNumber;
	private String sequenceCode;
	
	/*********************************************************************
	 * Accessors and mutators.
	**/
	public static int getStaticVoteNumber() {
		return staticVoteNumber;
	}
	public static void setStaticVoteNumber(int staticVoteNumber) {
		Choice.staticVoteNumber = staticVoteNumber;
	}
	public int getLocalVoteNumber() {
		return localVoteNumber;
	}
	public void setLocalVoteNumber(int localVoteNumber) {
		this.localVoteNumber = localVoteNumber;
	}
	public boolean isNewVote() {
		return isNewVote;
	}
	public void setNewVote(boolean isNewVote) {
		this.isNewVote = isNewVote;
	}
	public String getCandidateContest() {
		return candidateContest;
	}
	public void setCandidateContest(String candidateContest) {
		this.candidateContest = candidateContest;
	}
	public String getIvo() {
		return ivo;
	}
	public void setIvo(String ivo) {
		this.ivo = ivo;
	}
	public String getPctName() {
		return pctName;
	}
	public void setPctName(String pctName) {
		this.pctName = pctName;
	}
	public String getPctNumber() {
		return pctNumber;
	}
	public void setPctNumber(String pctNumber) {
		this.pctNumber = pctNumber;
	}
	public String getSequenceCode() {
		return sequenceCode;
	}
	public void setSequenceCode(String sequenceCode) {
		this.sequenceCode = sequenceCode;
	}
	
	
	/*********************************************************************
	 * Method to extract the precinct information from the 'String'.
	 *
	 * Extracting the pct info means getting rid of the "PRECINCT" and
	 * the hyphen from the input, taking the next piece of the 'String'
	 * as the pct number, and then taking rest of the input 'String'
	 * as the name of the pct.
	 *
	 * We make judicious use of 'trim()' in order to limit ourselves
	 * only to real data.
	 *
	 * @param pctData the 'String' from which to extract
	**/
	@Override
	public void extractPctData(String pctData) {
		// TODO Auto-generated method stub
		//example input string
		//PRECINCT 101 - Ward 1
		pctData.trim();
		Scanner tempScanner = new Scanner(pctData);
		tempScanner.next(); //gets rid of the words precinct
		this.pctNumber = tempScanner.next();
		tempScanner.next();
		this.pctName = tempScanner.nextLine();
		tempScanner.close(); // close out the scanner 
		
		
		
	}
	/*********************************************************************
	 * Method to parse an input line to create a cast vote choice.
	 *
	 * First we extract the pct info from the 'pctData' input parameter.
	 *
	 * Then we convert the input line to a 'Scanner' and read off the
	 * info one at a time.
	 *
	 * The only tricky part is that we may or may not have an asterisk
	 * so we have a variable number of strings to extract.
	 *
	 * If we have the asterisk at the appropriate location, we assume
	 * that we have a new vote and we bump that counter.
	 *
	 * @param pctData and inputLine to create choice
	**/
	@Override
	public void parseInput(String pctData, String inputLine) {
		// TODO Auto-generated method stub
		extractPctData(pctData);
	    inputLine = inputLine.trim();
	    Scanner tempScanner = new Scanner(inputLine);
	    this.ivo = tempScanner.next();
	    this.ballotStyle = tempScanner.next();

	    String output = tempScanner.next();
	    if(output.equals("*")){
	    	staticVoteNumber++;
	    	this.isNewVote = true;
	    	output = tempScanner.next();
	    }
	      sequenceCode = output;
	      this.candidateContest = tempScanner.nextLine();
	      this.localVoteNumber = staticVoteNumber;
		}
	/*********************************************************************
	 * Usual 'toString' method. It prints out information, in the order, and how you want it lined. 
	 *
	 * @return a formatted 'toString' of the class
	**/
	public String toString(){
		String string = ""; 
		
		string += String.format("%6s", this.localVoteNumber);
	    string += String.format("%5s", this.pctNumber);
	    string += String.format("%5s", this.pctName);
	    string += String.format("%5s", this.ivo);
	    string += String.format("%5s", this.ballotStyle);
	    string += String.format("%5s", this.sequenceCode);
	    string += String.format("%5s", this.candidateContest);
	 
	    
	
	    
		return string; 
		
	}

}
